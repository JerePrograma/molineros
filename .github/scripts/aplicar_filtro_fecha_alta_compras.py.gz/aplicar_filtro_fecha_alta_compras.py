#!/usr/bin/env python3
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]

DTO = ROOT / "ext-impl/src/ar/com/ospim/compras/requerimientos/beans/RequerimientoCompraFiltro.java"
ACTION = ROOT / "ext-impl/src/ar/com/ospim/compras/requerimientos/action/BuscarRequerimientosComprasAction.java"
SERVICE_UTIL = ROOT / "ext-impl/src/ar/com/ospim/compras/requerimientos/service/BusquedaRequerimientoCompraServiceUtil.java"
SERVICE_IMPL = ROOT / "ext-impl/src/ar/com/ospim/compras/requerimientos/service/BusquedaRequerimientoCompraServiceImpl.java"
SCHEMA = ROOT / "ext-impl/src/ar/com/ospim/compras/sql/compras_schema.sql"
JSP = ROOT / "ext-web/docroot/html/portlet/compras/requerimientos/requerimiento_compra_listado.jsp"
MIGRATION = ROOT / "docs/sql/20260903_filtrar_requerimientos_compras_por_fecha_alta.sql"

TARGETS = [
    DTO,
    ACTION,
    SERVICE_UTIL,
    SERVICE_IMPL,
    SCHEMA,
    JSP,
]


def read_latin1(path):
    data = path.read_bytes()

    if data.startswith(b"\xef\xbb\xbf"):
        raise RuntimeError("%s contiene BOM UTF-8" % path)

    if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
        raise RuntimeError("%s contiene BOM UTF-16" % path)

    return data.decode("iso-8859-1")


def write_latin1(path, text):
    data = text.encode("iso-8859-1")

    if data.startswith(b"\xef\xbb\xbf"):
        raise RuntimeError("%s quedaria con BOM UTF-8" % path)

    if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
        raise RuntimeError("%s quedaria con BOM UTF-16" % path)

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def replace_once(text, old, new, path, description):
    count = text.count(old)

    if count != 1:
        raise RuntimeError(
            "%s: se esperaban 1 coincidencia para %s y se encontraron %s"
            % (path, description, count)
        )

    return text.replace(old, new, 1)


def update_dto():
    text = read_latin1(DTO)

    text = replace_once(
        text,
        "import java.io.Serializable;\n",
        "import java.io.Serializable;\nimport java.util.Date;\n",
        DTO,
        "import Date",
    )

    text = replace_once(
        text,
        "    private Integer afiliadoIdSeccional;\n",
        "    private Integer afiliadoIdSeccional;\n"
        "    private Date fechaAltaDesde;\n"
        "    private Date fechaAltaHasta;\n",
        DTO,
        "campos de fecha de alta",
    )

    text = replace_once(
        text,
        "    public boolean tieneFiltros() {\n",
        "    public Date getFechaAltaDesde() {\n"
        "        return fechaAltaDesde;\n"
        "    }\n\n"
        "    public void setFechaAltaDesde(Date fechaAltaDesde) {\n"
        "        this.fechaAltaDesde = fechaAltaDesde;\n"
        "    }\n\n"
        "    public Date getFechaAltaHasta() {\n"
        "        return fechaAltaHasta;\n"
        "    }\n\n"
        "    public void setFechaAltaHasta(Date fechaAltaHasta) {\n"
        "        this.fechaAltaHasta = fechaAltaHasta;\n"
        "    }\n\n"
        "    public boolean tieneFiltros() {\n",
        DTO,
        "getters y setters de fecha",
    )

    text = replace_once(
        text,
        "                || surge != null\n"
        "                || !WebKeysCompras.isEmpty(texto);\n",
        "                || surge != null\n"
        "                || fechaAltaDesde != null\n"
        "                || fechaAltaHasta != null\n"
        "                || !WebKeysCompras.isEmpty(texto);\n",
        DTO,
        "tieneFiltros con fechas",
    )

    write_latin1(DTO, text)


def update_action():
    text = read_latin1(ACTION)

    text = replace_once(
        text,
        "import javax.portlet.*;\n"
        "import java.util.ArrayList;\n",
        "import javax.portlet.*;\n"
        "import java.text.SimpleDateFormat;\n"
        "import java.util.ArrayList;\n"
        "import java.util.Date;\n",
        ACTION,
        "imports de fecha",
    )

    text = replace_once(
        text,
        '            "sector_id",\n'
        '            "afiliado_cuil_titular",\n',
        '            "sector_id",\n'
        '            "fechaAltaDesdeDia",\n'
        '            "fechaAltaDesdeMes",\n'
        '            "fechaAltaDesdeAnio",\n'
        '            "fechaAltaHastaDia",\n'
        '            "fechaAltaHastaMes",\n'
        '            "fechaAltaHastaAnio",\n'
        '            "afiliado_cuil_titular",\n',
        ACTION,
        "parametros de busqueda de fecha",
    )

    text = replace_once(
        text,
        "    private RequerimientoCompraFiltro getFiltroFromRequest(RenderRequest request) {\n"
        "        RequerimientoCompraFiltro filtro = new RequerimientoCompraFiltro();\n\n",
        "    private RequerimientoCompraFiltro getFiltroFromRequest(\n"
        "            RenderRequest request) throws Exception {\n\n"
        "        RequerimientoCompraFiltro filtro =\n"
        "                new RequerimientoCompraFiltro();\n\n"
        "        Date fechaAltaDesde =\n"
        "                getFechaFromRequest(\n"
        "                        request,\n"
        '                        "fechaAltaDesde",\n'
        '                        "fecha de alta desde"\n'
        "                );\n\n"
        "        Date fechaAltaHasta =\n"
        "                getFechaFromRequest(\n"
        "                        request,\n"
        '                        "fechaAltaHasta",\n'
        '                        "fecha de alta hasta"\n'
        "                );\n\n"
        "        if (fechaAltaDesde != null\n"
        "                && fechaAltaHasta != null\n"
        "                && fechaAltaDesde.after(fechaAltaHasta)) {\n\n"
        "            throw new Exception(\n"
        '                    "La fecha de alta desde no puede ser posterior "\n'
        '                            + "a la fecha de alta hasta."\n'
        "            );\n"
        "        }\n\n"
        "        filtro.setFechaAltaDesde(fechaAltaDesde);\n"
        "        filtro.setFechaAltaHasta(fechaAltaHasta);\n\n",
        ACTION,
        "lectura del rango de fecha",
    )

    text = replace_once(
        text,
        "    private String getMensajeError(Exception e) {\n",
        "    private Date getFechaFromRequest(\n"
        "            RenderRequest request,\n"
        "            String prefijo,\n"
        "            String descripcion) throws Exception {\n\n"
        "        String diaRaw =\n"
        "                getParametro(\n"
        "                        request,\n"
        '                        prefijo + "Dia"\n'
        "                );\n\n"
        "        String mesRaw =\n"
        "                getParametro(\n"
        "                        request,\n"
        '                        prefijo + "Mes"\n'
        "                );\n\n"
        "        String anioRaw =\n"
        "                getParametro(\n"
        "                        request,\n"
        '                        prefijo + "Anio"\n'
        "                );\n\n"
        "        boolean diaInformado =\n"
        "                esParteFechaInformada(diaRaw);\n"
        "        boolean mesInformado =\n"
        "                esParteFechaInformada(mesRaw);\n"
        "        boolean anioInformado =\n"
        "                esParteFechaInformada(anioRaw);\n\n"
        "        if (!diaInformado\n"
        "                && !mesInformado\n"
        "                && !anioInformado) {\n\n"
        "            return null;\n"
        "        }\n\n"
        "        if (!diaInformado\n"
        "                || !mesInformado\n"
        "                || !anioInformado) {\n\n"
        "            throw new Exception(\n"
        '                    "Debe completar dia, mes y anio de la "\n'
        "                            + descripcion\n"
        '                            + "."\n'
        "            );\n"
        "        }\n\n"
        "        try {\n"
        "            int dia = Integer.parseInt(diaRaw);\n"
        "            int mes = Integer.parseInt(mesRaw);\n"
        "            int anio = Integer.parseInt(anioRaw);\n\n"
        "            if (dia < 1\n"
        "                    || dia > 31\n"
        "                    || mes < 0\n"
        "                    || mes > 11\n"
        "                    || anio < 1900\n"
        "                    || anio > 9999) {\n\n"
        "                throw new Exception();\n"
        "            }\n\n"
        "            SimpleDateFormat formato =\n"
        '                    new SimpleDateFormat("dd/MM/yyyy");\n\n'
        "            formato.setLenient(false);\n\n"
        "            return formato.parse(\n"
        "                    dia\n"
        '                            + "/"\n'
        "                            + (mes + 1)\n"
        '                            + "/"\n'
        "                            + anio\n"
        "            );\n"
        "        } catch (Exception e) {\n"
        "            throw new Exception(\n"
        '                    "La "\n'
        "                            + descripcion\n"
        '                            + " no es valida."\n'
        "            );\n"
        "        }\n"
        "    }\n\n"
        "    private boolean esParteFechaInformada(String value) {\n"
        "        return !WebKeysCompras.isEmpty(value)\n"
        '                && !"-1".equals(value);\n'
        "    }\n\n"
        "    private String getMensajeError(Exception e) {\n",
        ACTION,
        "parser estricto de fecha",
    )

    write_latin1(ACTION, text)


def update_service_util():
    text = read_latin1(SERVICE_UTIL)

    text = replace_once(
        text,
        "    public static List<RequerimientoCompra> buscarRequerimientos(\n"
        "            RequerimientoCompraFiltro filtro) throws Exception {\n\n"
        "        return getInstance().buscarRequerimientos(\n"
        "                filtro != null\n"
        "                        ? filtro\n"
        "                        : new RequerimientoCompraFiltro()\n"
        "        );\n"
        "    }\n",
        "    public static List<RequerimientoCompra> buscarRequerimientos(\n"
        "            RequerimientoCompraFiltro filtro) throws Exception {\n\n"
        "        RequerimientoCompraFiltro filtroEfectivo =\n"
        "                filtro != null\n"
        "                        ? filtro\n"
        "                        : new RequerimientoCompraFiltro();\n\n"
        "        validarFiltroBusqueda(filtroEfectivo);\n\n"
        "        return getInstance().buscarRequerimientos(\n"
        "                filtroEfectivo\n"
        "        );\n"
        "    }\n",
        SERVICE_UTIL,
        "validacion en buscarRequerimientos",
    )

    text = replace_once(
        text,
        "        RequerimientoCompraFiltro filtroEfectivo =\n"
        "                filtro != null\n"
        "                        ? filtro\n"
        "                        : new RequerimientoCompraFiltro();\n\n"
        "        List<RequerimientoCompra> requerimientos =\n",
        "        RequerimientoCompraFiltro filtroEfectivo =\n"
        "                filtro != null\n"
        "                        ? filtro\n"
        "                        : new RequerimientoCompraFiltro();\n\n"
        "        validarFiltroBusqueda(filtroEfectivo);\n\n"
        "        List<RequerimientoCompra> requerimientos =\n",
        SERVICE_UTIL,
        "validacion en buscarRequerimientosListado",
    )

    text = replace_once(
        text,
        "    private static void validarIdRequerimiento(\n",
        "    private static void validarFiltroBusqueda(\n"
        "            RequerimientoCompraFiltro filtro) throws Exception {\n\n"
        "        if (filtro == null) {\n"
        "            return;\n"
        "        }\n\n"
        "        if (filtro.getFechaAltaDesde() != null\n"
        "                && filtro.getFechaAltaHasta() != null\n"
        "                && filtro.getFechaAltaDesde().after(\n"
        "                        filtro.getFechaAltaHasta()\n"
        "                )) {\n\n"
        "            throw new Exception(\n"
        '                    "La fecha de alta desde no puede ser posterior "\n'
        '                            + "a la fecha de alta hasta."\n'
        "            );\n"
        "        }\n"
        "    }\n\n"
        "    private static void validarIdRequerimiento(\n",
        SERVICE_UTIL,
        "regla de rango en ServiceUtil",
    )

    write_latin1(SERVICE_UTIL, text)


def update_service_impl():
    text = read_latin1(SERVICE_IMPL)

    text = replace_once(
        text,
        '            "{call compras.buscar_requerimientos(?,?,?,?,?,?,?,?)}";\n',
        '            "{call compras.buscar_requerimientos(?,?,?,?,?,?,?,?,?,?)}";\n',
        SERVICE_IMPL,
        "CALL de diez parametros",
    )

    text = replace_once(
        text,
        "            setNullableBoolean(stmt, 7, filtro.getSurge());\n"
        "            stmt.setString(8, filtro.getTexto());\n\n"
        "            rs = stmt.executeQuery();\n",
        "            setNullableBoolean(stmt, 7, filtro.getSurge());\n"
        "            stmt.setString(8, filtro.getTexto());\n"
        "            setNullableDate(stmt, 9, filtro.getFechaAltaDesde());\n"
        "            setNullableDate(stmt, 10, filtro.getFechaAltaHasta());\n\n"
        "            rs = stmt.executeQuery();\n",
        SERVICE_IMPL,
        "parametros JDBC de fecha",
    )

    text = replace_once(
        text,
        "    private void setNullableBoolean(\n",
        "    private void setNullableDate(\n"
        "            CallableStatement stmt,\n"
        "            int index,\n"
        "            java.util.Date value) throws Exception {\n\n"
        "        if (value == null) {\n"
        "            stmt.setNull(index, Types.DATE);\n"
        "        } else {\n"
        "            stmt.setDate(\n"
        "                    index,\n"
        "                    new java.sql.Date(value.getTime())\n"
        "            );\n"
        "        }\n"
        "    }\n\n"
        "    private void setNullableBoolean(\n",
        SERVICE_IMPL,
        "helper JDBC nullable date",
    )

    write_latin1(SERVICE_IMPL, text)


def update_schema_and_create_migration():
    text = read_latin1(SCHEMA)

    start_marker = "CREATE FUNCTION compras.buscar_requerimientos(\n"
    end_marker = "CREATE FUNCTION compras.get_requerimiento(\n"

    if text.count(start_marker) != 1:
        raise RuntimeError(
            "%s: cantidad inesperada de funciones buscar_requerimientos"
            % SCHEMA
        )

    start = text.index(start_marker)
    end = text.index(end_marker, start)
    original = text[start:end]

    implementation = replace_once(
        original,
        "    p_surge BOOLEAN,\n"
        "    p_texto VARCHAR\n",
        "    p_surge BOOLEAN,\n"
        "    p_texto VARCHAR,\n"
        "    p_fecha_alta_desde DATE,\n"
        "    p_fecha_alta_hasta DATE\n",
        SCHEMA,
        "firma SQL con fechas",
    )

    implementation = replace_once(
        implementation,
        "  AND (\n"
        "    p_surge IS NULL\n"
        "        OR rb.surge = p_surge\n"
        "    )\n"
        "  AND (\n"
        "    v_texto IS NULL\n",
        "  AND (\n"
        "    p_surge IS NULL\n"
        "        OR rb.surge = p_surge\n"
        "    )\n"
        "  AND (\n"
        "    p_fecha_alta_desde IS NULL\n"
        "        OR rb.alta_fecha >= p_fecha_alta_desde\n"
        "    )\n"
        "  AND (\n"
        "    p_fecha_alta_hasta IS NULL\n"
        "        OR rb.alta_fecha\n"
        "            < p_fecha_alta_hasta + INTERVAL '1 day'\n"
        "    )\n"
        "  AND (\n"
        "    v_texto IS NULL\n",
        SCHEMA,
        "condiciones SQL de fecha",
    )

    wrapper = (
        "CREATE FUNCTION compras.buscar_requerimientos(\n"
        "    p_estado INTEGER,\n"
        "    p_sector INTEGER,\n"
        "    p_afiliado_cuil_titular VARCHAR,\n"
        "    p_afiliado_int INTEGER,\n"
        "    p_id_tercerizadora VARCHAR,\n"
        "    p_recupero BOOLEAN,\n"
        "    p_surge BOOLEAN,\n"
        "    p_texto VARCHAR\n"
        ")\n"
        "    RETURNS SETOF compras.requerimiento_base_row\n"
        "AS $func$\n"
        "BEGIN\n"
        "RETURN QUERY\n"
        "SELECT *\n"
        "FROM compras.buscar_requerimientos(\n"
        "    p_estado,\n"
        "    p_sector,\n"
        "    p_afiliado_cuil_titular,\n"
        "    p_afiliado_int,\n"
        "    p_id_tercerizadora,\n"
        "    p_recupero,\n"
        "    p_surge,\n"
        "    p_texto,\n"
        "    NULL::DATE,\n"
        "    NULL::DATE\n"
        ");\n"
        "END;\n"
        "$func$\n"
        "LANGUAGE plpgsql\n"
        "STABLE;\n"
    )

    replacement = implementation.rstrip() + "\n\n\n" + wrapper + "\n\n\n"
    text = text[:start] + replacement + text[end:]
    write_latin1(SCHEMA, text)

    if MIGRATION.exists():
        raise RuntimeError("%s ya existe" % MIGRATION)

    migration_implementation = implementation.replace(
        "CREATE FUNCTION compras.buscar_requerimientos(",
        "CREATE OR REPLACE FUNCTION compras.buscar_requerimientos(",
        1,
    )

    migration_wrapper = wrapper.replace(
        "CREATE FUNCTION compras.buscar_requerimientos(",
        "CREATE OR REPLACE FUNCTION compras.buscar_requerimientos(",
        1,
    )

    migration = (
        "-- Incorpora el filtro opcional por fecha de alta de requerimientos.\n"
        "-- Conserva la firma de ocho parametros como wrapper compatible.\n"
        "-- Ejecutar con:\n"
        "-- psql -X -v ON_ERROR_STOP=1 "
        "-f 20260903_filtrar_requerimientos_compras_por_fecha_alta.sql\n\n"
        "\\encoding LATIN1\n\n"
        "BEGIN;\n\n"
        "DO $precondition$\n"
        "BEGIN\n"
        "    IF to_regtype(\n"
        "           'compras.requerimiento_base_row'\n"
        "       ) IS NULL\n"
        "       OR to_regprocedure(\n"
        "              'compras.buscar_requerimientos("
        "integer,integer,character varying,integer,"
        "character varying,boolean,boolean,character varying)'\n"
        "          ) IS NULL THEN\n\n"
        "        RAISE EXCEPTION\n"
        "            'No esta disponible la busqueda base de requerimientos.';\n"
        "    END IF;\n"
        "END;\n"
        "$precondition$;\n\n"
        + migration_implementation.rstrip()
        + "\n\n\n"
        + migration_wrapper
        + "\n\n"
        "COMMIT;\n"
    )

    write_latin1(MIGRATION, migration)


def update_jsp():
    text = read_latin1(JSP)

    text = replace_once(
        text,
        "if (\"0\".equals(idTercerizadoraFiltro)) {\n"
        "    idTercerizadoraFiltro = \"\";\n"
        "}\n\n"
        "List<TercerizadoraServicio> tercerizadoras =\n",
        "if (\"0\".equals(idTercerizadoraFiltro)) {\n"
        "    idTercerizadoraFiltro = \"\";\n"
        "}\n\n"
        "Calendar fechaAltaDesde =\n"
        "        CalendarFactoryUtil.getCalendar();\n"
        "fechaAltaDesde.setTime(new Date());\n\n"
        "Calendar fechaAltaHasta =\n"
        "        CalendarFactoryUtil.getCalendar();\n"
        "fechaAltaHasta.setTime(new Date());\n\n"
        "List<TercerizadoraServicio> tercerizadoras =\n",
        JSP,
        "calendarios de fecha",
    )

    date_row = (
        "    <table class=\"lfr-table\">\n"
        "        <tr>\n"
        "            <td>\n"
        "                <label>Fecha de alta desde:</label>\n"
        "            </td>\n\n"
        "            <td>\n"
        "                <liferay-ui:input-date\n"
        "                        dayParam=\"fechaAltaDesdeDia\"\n"
        "                        dayValue=\"<%= fechaAltaDesde.get(Calendar.DATE) %>\"\n"
        "                        dayNullable=\"<%= true %>\"\n"
        "                        monthParam=\"fechaAltaDesdeMes\"\n"
        "                        monthValue=\"<%= fechaAltaDesde.get(Calendar.MONTH) %>\"\n"
        "                        monthNullable=\"<%= true %>\"\n"
        "                        yearParam=\"fechaAltaDesdeAnio\"\n"
        "                        yearValue=\"<%= fechaAltaDesde.get(Calendar.YEAR) %>\"\n"
        "                        yearNullable=\"<%= true %>\"\n"
        "                        yearRangeStart=\"<%= fechaAltaDesde.get(Calendar.YEAR) - 50 %>\"\n"
        "                        yearRangeEnd=\"<%= fechaAltaDesde.get(Calendar.YEAR) + 2 %>\"\n"
        "                        firstDayOfWeek=\"<%= fechaAltaDesde.getFirstDayOfWeek() - 1 %>\"\n"
        "                        disabled=\"<%= false %>\" />\n"
        "            </td>\n\n"
        "            <td>\n"
        "                <label>Fecha de alta hasta:</label>\n"
        "            </td>\n\n"
        "            <td>\n"
        "                <liferay-ui:input-date\n"
        "                        dayParam=\"fechaAltaHastaDia\"\n"
        "                        dayValue=\"<%= fechaAltaHasta.get(Calendar.DATE) %>\"\n"
        "                        dayNullable=\"<%= true %>\"\n"
        "                        monthParam=\"fechaAltaHastaMes\"\n"
        "                        monthValue=\"<%= fechaAltaHasta.get(Calendar.MONTH) %>\"\n"
        "                        monthNullable=\"<%= true %>\"\n"
        "                        yearParam=\"fechaAltaHastaAnio\"\n"
        "                        yearValue=\"<%= fechaAltaHasta.get(Calendar.YEAR) %>\"\n"
        "                        yearNullable=\"<%= true %>\"\n"
        "                        yearRangeStart=\"<%= fechaAltaHasta.get(Calendar.YEAR) - 50 %>\"\n"
        "                        yearRangeEnd=\"<%= fechaAltaHasta.get(Calendar.YEAR) + 2 %>\"\n"
        "                        firstDayOfWeek=\"<%= fechaAltaHasta.getFirstDayOfWeek() - 1 %>\"\n"
        "                        disabled=\"<%= false %>\" />\n"
        "            </td>\n\n"
        "            <td colspan=\"2\"></td>\n"
        "        </tr>\n\n"
        "        <tr>\n"
        "            <td>\n"
        "                <label>Estado:</label>\n"
    )

    text = replace_once(
        text,
        "    <table class=\"lfr-table\">\n"
        "        <tr>\n"
        "            <td>\n"
        "                <label>Estado:</label>\n",
        date_row,
        JSP,
        "fila visual de fecha",
    )

    date_functions = (
        "    function <portlet:namespace />limpiarCampoSiExiste(id) {\n"
        "        var campo = jQuery(\n"
        "                '#<portlet:namespace />' + id\n"
        "        );\n\n"
        "        if (campo.length > 0) {\n"
        "            campo.val('');\n"
        "        }\n"
        "    }\n\n"
        "    function <portlet:namespace />normalizarValorFechaAlta(value) {\n"
        "        if (value == null || value == '-1') {\n"
        "            return '';\n"
        "        }\n\n"
        "        return jQuery.trim(value);\n"
        "    }\n\n"
        "    function <portlet:namespace />limpiarFechasAltaFiltro() {\n"
        "        jQuery('#<portlet:namespace />fechaAltaDesdeDia').val('');\n"
        "        jQuery('#<portlet:namespace />fechaAltaDesdeMes').val('');\n"
        "        jQuery('#<portlet:namespace />fechaAltaDesdeAnio').val('');\n"
        "        jQuery('#<portlet:namespace />fechaAltaHastaDia').val('');\n"
        "        jQuery('#<portlet:namespace />fechaAltaHastaMes').val('');\n"
        "        jQuery('#<portlet:namespace />fechaAltaHastaAnio').val('');\n"
        "    }\n\n"
        "    function <portlet:namespace />obtenerFechaAltaFiltro(\n"
        "            prefijo,\n"
        "            descripcion) {\n\n"
        "        var dia =\n"
        "                <portlet:namespace />normalizarValorFechaAlta(\n"
        "                        jQuery(\n"
        "                                '#<portlet:namespace />'\n"
        "                                + prefijo\n"
        "                                + 'Dia'\n"
        "                        ).val()\n"
        "                );\n\n"
        "        var mes =\n"
        "                <portlet:namespace />normalizarValorFechaAlta(\n"
        "                        jQuery(\n"
        "                                '#<portlet:namespace />'\n"
        "                                + prefijo\n"
        "                                + 'Mes'\n"
        "                        ).val()\n"
        "                );\n\n"
        "        var anio =\n"
        "                <portlet:namespace />normalizarValorFechaAlta(\n"
        "                        jQuery(\n"
        "                                '#<portlet:namespace />'\n"
        "                                + prefijo\n"
        "                                + 'Anio'\n"
        "                        ).val()\n"
        "                );\n\n"
        "        var algunoInformado =\n"
        "                dia != ''\n"
        "                || mes != ''\n"
        "                || anio != '';\n\n"
        "        if (!algunoInformado) {\n"
        "            return null;\n"
        "        }\n\n"
        "        if (dia == '' || mes == '' || anio == '') {\n"
        "            alert(\n"
        "                    'Debe completar dia, mes y anio de la '\n"
        "                    + descripcion\n"
        "                    + '.'\n"
        "            );\n\n"
        "            return false;\n"
        "        }\n\n"
        "        var diaNumero = parseInt(dia, 10);\n"
        "        var mesNumero = parseInt(mes, 10);\n"
        "        var anioNumero = parseInt(anio, 10);\n"
        "        var fecha =\n"
        "                new Date(\n"
        "                        anioNumero,\n"
        "                        mesNumero,\n"
        "                        diaNumero\n"
        "                );\n\n"
        "        if (fecha.getFullYear() != anioNumero\n"
        "                || fecha.getMonth() != mesNumero\n"
        "                || fecha.getDate() != diaNumero) {\n\n"
        "            alert(\n"
        "                    'La '\n"
        "                    + descripcion\n"
        "                    + ' no es valida.'\n"
        "            );\n\n"
        "            return false;\n"
        "        }\n\n"
        "        return fecha;\n"
        "    }\n\n"
        "    function <portlet:namespace />validarFechasAltaFiltro() {\n"
        "        var fechaDesde =\n"
        "                <portlet:namespace />obtenerFechaAltaFiltro(\n"
        "                        'fechaAltaDesde',\n"
        "                        'fecha de alta desde'\n"
        "                );\n\n"
        "        if (fechaDesde === false) {\n"
        "            return false;\n"
        "        }\n\n"
        "        var fechaHasta =\n"
        "                <portlet:namespace />obtenerFechaAltaFiltro(\n"
        "                        'fechaAltaHasta',\n"
        "                        'fecha de alta hasta'\n"
        "                );\n\n"
        "        if (fechaHasta === false) {\n"
        "            return false;\n"
        "        }\n\n"
        "        if (fechaDesde != null\n"
        "                && fechaHasta != null\n"
        "                && fechaDesde.getTime() > fechaHasta.getTime()) {\n\n"
        "            alert(\n"
        "                    'La fecha de alta desde no puede ser posterior '\n"
        "                    + 'a la fecha de alta hasta.'\n"
        "            );\n\n"
        "            return false;\n"
        "        }\n\n"
        "        return true;\n"
        "    }\n\n"
    )

    text = replace_once(
        text,
        "    function <portlet:namespace />limpiarCampoSiExiste(id) {\n"
        "        var campo = jQuery(\n"
        "                '#<portlet:namespace />' + id\n"
        "        );\n\n"
        "        if (campo.length > 0) {\n"
        "            campo.val('');\n"
        "        }\n"
        "    }\n\n",
        date_functions,
        JSP,
        "funciones JavaScript de fecha",
    )

    text = replace_once(
        text,
        "        if (typeof <portlet:namespace />limpiarCamposAfiliado\n"
        "                == 'function') {\n"
        "            <portlet:namespace />limpiarCamposAfiliado();\n"
        "        }\n\n"
        "        jQuery(\n"
        "                '#<portlet:namespace />estado'\n",
        "        if (typeof <portlet:namespace />limpiarCamposAfiliado\n"
        "                == 'function') {\n"
        "            <portlet:namespace />limpiarCamposAfiliado();\n"
        "        }\n\n"
        "        <portlet:namespace />limpiarFechasAltaFiltro();\n\n"
        "        jQuery(\n"
        "                '#<portlet:namespace />estado'\n",
        JSP,
        "limpieza del rango",
    )

    text = replace_once(
        text,
        "        <portlet:namespace />sincronizarAfiliadoFiltro();\n"
        "        <portlet:namespace />desbloquearTercerizadoraFiltro(false);\n\n"
        "        var cuil = jQuery.trim(\n",
        "        <portlet:namespace />sincronizarAfiliadoFiltro();\n"
        "        <portlet:namespace />desbloquearTercerizadoraFiltro(false);\n\n"
        "        if (!<portlet:namespace />validarFechasAltaFiltro()) {\n"
        "            return false;\n"
        "        }\n\n"
        "        var cuil = jQuery.trim(\n",
        JSP,
        "validacion del rango",
    )

    text = replace_once(
        text,
        "        var sector_id =\n"
        "                jQuery('#<portlet:namespace />sector_id').val();\n\n"
        "        var afiliado_cuil_titular =\n",
        "        var sector_id =\n"
        "                jQuery('#<portlet:namespace />sector_id').val();\n\n"
        "        var fechaAltaDesdeDia =\n"
        "                <portlet:namespace />normalizarValorFechaAlta(\n"
        "                        jQuery(\n"
        "                                '#<portlet:namespace />fechaAltaDesdeDia'\n"
        "                        ).val()\n"
        "                );\n\n"
        "        var fechaAltaDesdeMes =\n"
        "                <portlet:namespace />normalizarValorFechaAlta(\n"
        "                        jQuery(\n"
        "                                '#<portlet:namespace />fechaAltaDesdeMes'\n"
        "                        ).val()\n"
        "                );\n\n"
        "        var fechaAltaDesdeAnio =\n"
        "                <portlet:namespace />normalizarValorFechaAlta(\n"
        "                        jQuery(\n"
        "                                '#<portlet:namespace />fechaAltaDesdeAnio'\n"
        "                        ).val()\n"
        "                );\n\n"
        "        var fechaAltaHastaDia =\n"
        "                <portlet:namespace />normalizarValorFechaAlta(\n"
        "                        jQuery(\n"
        "                                '#<portlet:namespace />fechaAltaHastaDia'\n"
        "                        ).val()\n"
        "                );\n\n"
        "        var fechaAltaHastaMes =\n"
        "                <portlet:namespace />normalizarValorFechaAlta(\n"
        "                        jQuery(\n"
        "                                '#<portlet:namespace />fechaAltaHastaMes'\n"
        "                        ).val()\n"
        "                );\n\n"
        "        var fechaAltaHastaAnio =\n"
        "                <portlet:namespace />normalizarValorFechaAlta(\n"
        "                        jQuery(\n"
        "                                '#<portlet:namespace />fechaAltaHastaAnio'\n"
        "                        ).val()\n"
        "                );\n\n"
        "        var afiliado_cuil_titular =\n",
        JSP,
        "lectura JavaScript de fechas",
    )

    text = replace_once(
        text,
        "                + '&sector_id=' + encodeURIComponent(sector_id)\n"
        "                + '&afiliado_cuil_titular='\n",
        "                + '&sector_id=' + encodeURIComponent(sector_id)\n"
        "                + '&fechaAltaDesdeDia='\n"
        "                    + encodeURIComponent(fechaAltaDesdeDia)\n"
        "                + '&fechaAltaDesdeMes='\n"
        "                    + encodeURIComponent(fechaAltaDesdeMes)\n"
        "                + '&fechaAltaDesdeAnio='\n"
        "                    + encodeURIComponent(fechaAltaDesdeAnio)\n"
        "                + '&fechaAltaHastaDia='\n"
        "                    + encodeURIComponent(fechaAltaHastaDia)\n"
        "                + '&fechaAltaHastaMes='\n"
        "                    + encodeURIComponent(fechaAltaHastaMes)\n"
        "                + '&fechaAltaHastaAnio='\n"
        "                    + encodeURIComponent(fechaAltaHastaAnio)\n"
        "                + '&afiliado_cuil_titular='\n",
        JSP,
        "parametros sin namespace",
    )

    text = replace_once(
        text,
        "                + '&<portlet:namespace />sector_id='\n"
        "                    + encodeURIComponent(sector_id)\n"
        "                + '&<portlet:namespace />afiliado_cuil_titular='\n",
        "                + '&<portlet:namespace />sector_id='\n"
        "                    + encodeURIComponent(sector_id)\n"
        "                + '&<portlet:namespace />fechaAltaDesdeDia='\n"
        "                    + encodeURIComponent(fechaAltaDesdeDia)\n"
        "                + '&<portlet:namespace />fechaAltaDesdeMes='\n"
        "                    + encodeURIComponent(fechaAltaDesdeMes)\n"
        "                + '&<portlet:namespace />fechaAltaDesdeAnio='\n"
        "                    + encodeURIComponent(fechaAltaDesdeAnio)\n"
        "                + '&<portlet:namespace />fechaAltaHastaDia='\n"
        "                    + encodeURIComponent(fechaAltaHastaDia)\n"
        "                + '&<portlet:namespace />fechaAltaHastaMes='\n"
        "                    + encodeURIComponent(fechaAltaHastaMes)\n"
        "                + '&<portlet:namespace />fechaAltaHastaAnio='\n"
        "                    + encodeURIComponent(fechaAltaHastaAnio)\n"
        "                + '&<portlet:namespace />afiliado_cuil_titular='\n",
        JSP,
        "parametros con namespace",
    )

    text = replace_once(
        text,
        "        <portlet:namespace />desbloquearTercerizadoraFiltro(false);\n"
        "        jQuery('#<portlet:namespace />buscando').show();\n",
        "        <portlet:namespace />limpiarFechasAltaFiltro();\n"
        "        <portlet:namespace />desbloquearTercerizadoraFiltro(false);\n"
        "        jQuery('#<portlet:namespace />buscando').show();\n",
        JSP,
        "inicializacion de fechas vacias",
    )

    write_latin1(JSP, text)


def validate_results():
    expected = {
        DTO: [
            "private Date fechaAltaDesde;",
            "private Date fechaAltaHasta;",
            "getFechaAltaDesde()",
            "getFechaAltaHasta()",
        ],
        ACTION: [
            '"fechaAltaDesdeDia"',
            '"fechaAltaHastaAnio"',
            "getFechaFromRequest(",
            "formato.setLenient(false);",
        ],
        SERVICE_UTIL: [
            "validarFiltroBusqueda(filtroEfectivo);",
            "filtro.getFechaAltaDesde().after(",
        ],
        SERVICE_IMPL: [
            "buscar_requerimientos(?,?,?,?,?,?,?,?,?,?)",
            "setNullableDate(stmt, 9",
            "setNullableDate(stmt, 10",
        ],
        SCHEMA: [
            "p_fecha_alta_desde DATE",
            "p_fecha_alta_hasta DATE",
            "< p_fecha_alta_hasta + INTERVAL '1 day'",
            "NULL::DATE",
        ],
        JSP: [
            'dayParam="fechaAltaDesdeDia"',
            'dayParam="fechaAltaHastaDia"',
            "validarFechasAltaFiltro()",
            "&fechaAltaDesdeDia=",
            "&<portlet:namespace />fechaAltaHastaAnio=",
        ],
        MIGRATION: [
            "CREATE OR REPLACE FUNCTION compras.buscar_requerimientos(",
            "p_fecha_alta_desde DATE",
            "NULL::DATE",
            "COMMIT;",
        ],
    }

    for path, markers in expected.items():
        text = read_latin1(path)

        for marker in markers:
            if marker not in text:
                raise RuntimeError(
                    "%s: no se encontro el marcador %r"
                    % (path, marker)
                )

        data = path.read_bytes()

        if data.startswith(b"\xef\xbb\xbf"):
            raise RuntimeError("%s contiene BOM UTF-8" % path)

        if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
            raise RuntimeError("%s contiene BOM UTF-16" % path)

        if data.decode("iso-8859-1").encode("iso-8859-1") != data:
            raise RuntimeError("%s no conserva ISO-8859-1" % path)


def main():
    update_dto()
    update_action()
    update_service_util()
    update_service_impl()
    update_schema_and_create_migration()
    update_jsp()
    validate_results()


if __name__ == "__main__":
    main()
